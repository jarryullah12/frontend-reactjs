import React, { useState, useEffect } from 'react';
import { useAuthStore } from '@/store';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/lib/supabase';
import disposableDomains from 'disposable-email-domains';
import MailChecker from 'mailchecker';

const GoogleIcon = () => (
  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
    <path
      fill="#4285F4"
      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    />
    <path
      fill="#34A853"
      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
    />
    <path
      fill="#FBBC05"
      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
    />
    <path
      fill="#EA4335"
      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
    />
  </svg>
);

export function Signup() {
  const { t } = useTranslation();
  const { login } = useAuthStore();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { user } = session;
        
        if (user.email) {
          const trimmedEmail = user.email.trim().toLowerCase();
          const domain = trimmedEmail.split('@')[1];
          if (domain) {
            const parts = domain.split('.');
            const baseDomain = parts.length > 2 ? parts.slice(-2).join('.') : domain;
            const domainsList = Array.isArray(disposableDomains) ? disposableDomains : Object.values(disposableDomains || {});
            const CUSTOM_BLOCKLIST = ['kynninc.com', 'tozya.com', 'maxsmail.com', 'fmaildes.com', 'mailto.plus', '1secmail.com', '1secmail.net', '1secmail.org'];
            const isDisposable = domainsList.includes(domain) || domainsList.includes(baseDomain) || 
              CUSTOM_BLOCKLIST.includes(domain) || CUSTOM_BLOCKLIST.includes(baseDomain) || 
              !MailChecker.isValid(user.email) ||
              /temp|throwaway|disposable|fake|10minute|yopmail|mailinator|trash|guerrilla|nada|drop|burner|generator|kynninc/i.test(domain);
            
            if (isDisposable) {
              setErrorMsg('Disposable email addresses are not allowed. Please use a verified provider.');
              await supabase.auth.signOut();
              return;
            }
          }
        }
        
        try {
          // Check if user exists in our custom 'users' table
          const { data: existingUser } = await supabase
            .from('users')
            .select('*')
            .eq('email', user.email)
            .single();
          
          if (existingUser) {
            login({ id: existingUser.id, name: existingUser.name, email: existingUser.email, role: existingUser.role, joinDate: existingUser.join_date });
            if (window.location.hash) {
              window.history.replaceState(null, '', window.location.pathname + window.location.search);
            }
            navigate('/');
          } else {
            // Create new user
            const { data: newUser, error: insertError } = await supabase
              .from('users')
              .insert([{
                name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'Google User',
                email: user.email,
                password: 'google-oauth-placeholder',
                role: 'user'
              }])
              .select()
              .single();
              
            if (newUser) {
              login({ id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role, joinDate: newUser.join_date });
              if (window.location.hash) {
                window.history.replaceState(null, '', window.location.pathname + window.location.search);
              }
              navigate('/');
            } else if (insertError) {
              console.error('Error creating user from Google signup:', insertError);
              setErrorMsg('Failed to create user account from Google signup.');
            }
          }
        } catch (err) {
          console.error('Error handling Google signup callback:', err);
        }
      }
    };
    
    checkSession();
    
    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session) {
        checkSession();
      }
    });
    
    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [login, navigate]);

  const handleGoogleSignup = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin + '/signup'
        }
      });
      if (error) throw error;
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to initialize Google signup.');
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    
    if (email) {
      const trimmedEmail = email.trim().toLowerCase();
      const domain = trimmedEmail.split('@')[1];
      if (domain) {
        const parts = domain.split('.');
        const baseDomain = parts.length > 2 ? parts.slice(-2).join('.') : domain;
        const domainsList = Array.isArray(disposableDomains) ? disposableDomains : Object.values(disposableDomains || {});
        const CUSTOM_BLOCKLIST = ['kynninc.com', 'tozya.com', 'maxsmail.com', 'fmaildes.com', 'mailto.plus', '1secmail.com', '1secmail.net', '1secmail.org'];
        const isDisposable = domainsList.includes(domain) || domainsList.includes(baseDomain) || 
          CUSTOM_BLOCKLIST.includes(domain) || CUSTOM_BLOCKLIST.includes(baseDomain) || 
          !MailChecker.isValid(email) ||
          /temp|throwaway|disposable|fake|10minute|yopmail|mailinator|trash|guerrilla|nada|drop|burner|generator|kynninc/i.test(domain);
        
        if (isDisposable) {
          setErrorMsg('Disposable email addresses are not allowed. Please use a verified provider.');
          return;
        }
      }
    }

    try {
      // Insert user into Supabase
      const { data, error } = await supabase.from('users').insert([
        { name, email, password, role: 'user' }
      ]).select();

      if (error) {
        console.error('Supabase Error creating user:', error);
        setErrorMsg(`Database Error (${error.code || 'Unknown'}): ${error.message}`);
        return; // Stop here so user can read the error
      }

      if (data && data.length > 0) {
        console.log('User created successfully in Supabase');
        login({ id: data[0].id, name, email, role: 'user', joinDate: data[0].join_date });
        navigate('/');
      } else {
        setErrorMsg('Failed to create account: No data returned from database.');
      }
    } catch (err: any) {
      console.error('Exception during signup:', err);
      setErrorMsg(`Error: ${err.message || 'Unknown error occurred'}`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-950 px-4 transition-colors duration-200">
      <div className="w-full max-w-md">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          {t('signup.back_home')}
        </Link>
        
        <div className="bg-white dark:bg-gray-900 p-8 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{t('signup.title')}</h1>
            <p className="text-gray-500 dark:text-gray-400">{t('signup.subtitle')}</p>
          </div>
          
          {errorMsg && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-xl text-sm">
              {errorMsg}
            </div>
          )}
          
          <form onSubmit={handleSignup} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">{t('signup.name')}</label>
              <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-950 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#4f39f6] focus:border-[#4f39f6] transition-shadow" placeholder="John Doe" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">{t('signup.email')}</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-950 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#4f39f6] focus:border-[#4f39f6] transition-shadow" placeholder="you@example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">{t('signup.password')}</label>
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-950 text-gray-900 dark:text-white focus:ring-2 focus:ring-[#4f39f6] focus:border-[#4f39f6] transition-shadow" placeholder="••••••••" />
            </div>
            <button type="submit" className="w-full py-3 bg-[#4f39f6] text-white rounded-xl font-medium hover:bg-[#4f39f6]/90 transition-colors shadow-sm">
              {t('signup.submit')}
            </button>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200 dark:border-gray-800"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-900 text-gray-500">Or continue with</span>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={handleGoogleSignup}
                type="button"
                className="w-full flex items-center justify-center py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl shadow-sm bg-white dark:bg-gray-950 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors"
              >
                <GoogleIcon />
                Sign up with Google
              </button>
            </div>
          </div>
          
          <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
            {t('signup.has_account')}{' '}
            <Link to="/login" className="font-medium text-[#4f39f6] dark:text-[#4f39f6] hover:text-[#4f39f6]/80">
              {t('signup.login')}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
